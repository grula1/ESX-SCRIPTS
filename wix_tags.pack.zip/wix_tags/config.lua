-- __          _________   __    _____                 _                                  _   
-- \ \        / /_   _\ \ / /   |  __ \               | |                                | |  
--  \ \  /\  / /  | |  \ V /    | |  | | _____   _____| | ___  _ __  _ __ ___   ___ _ __ | |_ 
--   \ \/  \/ /   | |   > <     | |  | |/ _ \ \ / / _ \ |/ _ \| '_ \| '_ ` _ \ / _ \ '_ \| __|
--    \  /\  /   _| |_ / . \    | |__| |  __/\ V /  __/ | (_) | |_) | | | | | |  __/ | | | |_ 
--     \/  \/   |_____/_/ \_\   |_____/ \___| \_/ \___|_|\___/| .__/|_| |_| |_|\___|_| |_|\__|
--                                                            | |                             
--                                                            |_|                             
Config = {}

Config.SeeDistance = 25 -- Set the maximum distance in units that tags can be seen from.
Config.TextScale = 0.35 -- Set the size of the text for the tags.
Config.ZAxisOffset = 1.0 -- Set the Z-axis offset for the tags. Recommended not to touch. Make sure to write it in the same format. Example: dont write 2 write 2.0
Config.Font = 0 -- https://gtaforums.com/topic/794014-fonts-list/

Config.NearCheckWait = 500 -- Set the time in milliseconds to wait before checking for nearby players.

Config.GroupTags = { -- Table to store group tags.
    owner = 'OWNER',
    developer = 'DEVELOPER',
    staff = 'STAFF',
    admin = 'ADMIN',
   -- moderator = 'MODERATOR', Add more tags.
}
